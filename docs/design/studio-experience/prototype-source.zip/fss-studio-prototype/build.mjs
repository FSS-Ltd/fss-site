import { createRequire } from "node:module";
import { mkdir, readFile, writeFile } from "node:fs/promises";
const require = createRequire(import.meta.url);
let esbuild;
try {
  esbuild = require("esbuild");
} catch {
  esbuild = createRequire(require.resolve("tsx"))("esbuild");
}
await mkdir("dist", { recursive: true });
await esbuild.build({
  entryPoints: ["src/main.tsx"],
  bundle: true,
  loader: { ".ttf": "dataurl", ".png": "dataurl" },
  minify: true,
  outfile: "dist/app.js",
  format: "iife",
  target: ["safari16.4", "chrome111"],
  define: { "process.env.NODE_ENV": '"production"' },
  legalComments: "linked",
});
const [js, css] = await Promise.all([
  readFile("dist/app.js", "utf8"),
  readFile("dist/app.css", "utf8"),
]);
const html = `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>FSS Studio · Design review</title><style>${css}</style></head><body><div id="root"></div><script>${js.replaceAll("</script", "<\\/script")}</script></body></html>`;
await writeFile("index.html", html);
console.log(
  "Built standalone index.html. Open directly in a browser; no server or network required.",
);
