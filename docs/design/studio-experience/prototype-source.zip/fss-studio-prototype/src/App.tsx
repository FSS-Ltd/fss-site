import { ReviewContent } from "./Review";
import { useCallback, useEffect, useState } from "react";
import {
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  CircleHelp,
  LayoutGrid,
  Monitor,
  Smartphone,
} from "lucide-react";
import rawScreens from "./screens.json";
import { initialRequests, destinations } from "./request-data";
import { actionScreens } from "./actions";
import type { Notice, RequestItem, RequestState, Role, Screen } from "./types";
import { Badge, Button, Modal } from "./ui";
import { Shell, clientNav, founderNav } from "./Shell";
import { Board } from "./Board";
import { Home, Welcome } from "./Home";
import { GenericView } from "./GenericView";
import { Catalog } from "./Catalog";
import { DetailDialog, MoveDialog, NewRequestDialog } from "./RequestDialogs";
import { EmailDialog, Notifications } from "./Notifications";

const screens: Screen[] = rawScreens.filter(
  (s) => !["C00", "S05"].includes(s.id),
);
type Overlay =
  | { kind: "navigation" }
  | { kind: "catalog" }
  | { kind: "new"; bug?: boolean }
  | { kind: "notifications" }
  | { kind: "email"; notice: Notice }
  | { kind: "detail"; id: string }
  | { kind: "move"; id: string; destination?: RequestState }
  | { kind: "action"; label: string }
  | null;
export function App() {
  const [id, setId] = useState(() =>
    screens.some((s) => s.id === location.hash.slice(1))
      ? location.hash.slice(1)
      : "C05",
  );
  const [role, setRole] = useState<Role>(() =>
    id.startsWith("F") ? "Founder" : "Client",
  );
  const [phone, setPhone] = useState(false);
  const [overlay, setOverlay] = useState<Overlay>(null);
  const [requests, setRequests] = useState(initialRequests);
  const [toast, setToast] = useState("");
  const [notices, setNotices] = useState<Notice[]>([
    {
      id: 1,
      title: "Your booking flow is ready for review",
      body: "Version 3 includes clearer appointment details and a simpler mobile flow.",
      read: false,
    },
    {
      id: 2,
      title: "Brand landing page is complete",
      body: "The approved landing page and final files are ready in your workspace.",
      read: false,
    },
  ]);
  const screen = screens.find((s) => s.id === id) ?? screens[0];
  const navigate = useCallback((next: string) => {
    const target = screens.find((s) => s.id === next);
    if (!target) return;
    location.hash = next;
    setId(next);
    setRole(target.role === "Founder" ? "Founder" : "Client");
    setOverlay(null);
    window.scrollTo({ top: 0, behavior: "instant" });
  }, []);
  useEffect(() => {
    const listener = () => {
      const target = screens.find((s) => s.id === location.hash.slice(1));
      if (target) {
        setId(target.id);
        setRole(target.role === "Founder" ? "Founder" : "Client");
        setOverlay(null);
      }
    };
    window.addEventListener("hashchange", listener);
    return () => window.removeEventListener("hashchange", listener);
  }, []);
  useEffect(() => {
    if (!toast) return;
    const timer = setTimeout(() => setToast(""), 4500);
    return () => clearTimeout(timer);
  }, [toast]);
  useEffect(() => {
    const listener = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key === "k") {
        event.preventDefault();
        setOverlay({ kind: "catalog" });
      }
    };
    window.addEventListener("keydown", listener);
    return () => window.removeEventListener("keydown", listener);
  }, []);
  const selected =
    overlay && (overlay.kind === "move" || overlay.kind === "detail")
      ? requests.find((r) => r.id === overlay.id)
      : undefined;
  function createRequest(data: {
    title: string;
    description: string;
    type: "Request" | "Bug";
  }) {
    const request: RequestItem = {
      ...data,
      id: `NS-${String(Math.max(...requests.map((r) => Number(r.id.slice(3)))) + 1).padStart(3, "0")}`,
      state: "New",
      priority: "Normal",
      owner: role === "Founder" ? "Jean Fidele" : "Alex Morgan",
      comments: 0,
      attachments: 0,
      done: 0,
      total: 1,
      date: "Awaiting scope review",
    };
    setRequests((prev) => [request, ...prev]);
    setOverlay(null);
    navigate(role === "Founder" ? "F05" : "C05");
    setToast(`${request.id} created in this preview.`);
  }
  function move(request: RequestItem, state: RequestState, summary: string) {
    if (!destinations(request, role).includes(state)) {
      setToast("This transition is unavailable for the current role.");
      return;
    }
    setRequests((prev) =>
      prev.map((r) =>
        r.id === request.id
          ? {
              ...r,
              state,
              done: state === "Done" ? r.total : r.done,
              date: state === "Done" ? "Accepted just now" : r.date,
            }
          : r,
      ),
    );
    setOverlay(null);
    setToast(`${request.id} moved to ${state.toLowerCase()}.`);
    if (
      state === "Ready for review" ||
      state === "Done" ||
      state === "Changes requested"
    )
      setNotices((prev) => [
        {
          id: Date.now(),
          title:
            state === "Done"
              ? `${request.title} is complete`
              : state === "Changes requested"
                ? `Feedback received: ${request.title}`
                : `Ready for review: ${request.title}`,
          body: summary || request.description,
          read: false,
        },
        ...prev,
      ]);
  }
  function act(label: string) {
    if (
      /^(new request|create first request|bug report|report a bug)$/i.test(
        label,
      )
    ) {
      setOverlay({ kind: "new", bug: /bug/i.test(label) });
      return;
    }
    if (label === "Mark all as read") {
      setNotices((prev) => prev.map((n) => ({ ...n, read: true })));
      setToast("All preview notifications marked as read.");
      return;
    }
    if (actionScreens[label]) {
      navigate(actionScreens[label]);
      return;
    }
    if (/save|submit assets/i.test(label)) {
      setToast("Draft changes retained for this preview session.");
      return;
    }
    setOverlay({ kind: "action", label });
  }
  const main =
    id === "C05" || id === "F05" || id === "M03" ? (
      <Board
        role={role}
        requests={requests}
        navigate={navigate}
        onNew={() => setOverlay({ kind: "new" })}
        onOpen={(r) =>
          setOverlay({
            kind:
              r.state === "Ready for review" && role === "Client"
                ? "move"
                : "detail",
            id: r.id,
          })
        }
        onMove={(r, destination) =>
          setOverlay({ kind: "move", id: r.id, destination })
        }
        notify={setToast}
      />
    ) : ["C01", "F01", "M01", "M07"].includes(id) ? (
      <Home
        role={role}
        navigate={navigate}
        onNew={() => setOverlay({ kind: "new" })}
      />
    ) : ["C02", "M02"].includes(id) ? (
      <Welcome navigate={navigate} />
    ) : ["C09", "M05"].includes(id) ? (
      <>
        <div className="page-heading">
          <div>
            <div className="eyebrow">YOUR FEEDBACK MATTERS</div>
            <h1>Ready for your review.</h1>
            <p className="page-subtitle">
              Booking experience · NS-011 · Version 3
            </p>
          </div>
          <Badge>Review by 18 Sep</Badge>
        </div>
        <ReviewContent
          request={requests.find((r) => r.id === "NS-011") ?? requests[0]}
          onDecision={(state, summary) => {
            const request = requests.find((r) => r.id === "NS-011");
            if (request) {
              move(request, state, summary);
              navigate(state === "Done" ? "C11" : "C10");
            }
          }}
        />
      </>
    ) : (
      <GenericView key={id} screen={screen} act={act} navigate={navigate} />
    );
  const index = screens.findIndex((s) => s.id === id);
  return (
    <>
      <a href="#main-content" className="skip-link">
        Skip to content
      </a>
      <div className="review-bar">
        <span className="review-label">
          <span />
          Design review <small>Sample data · no emails sent</small>
        </span>
        <div className="review-tools">
          <div className="role-switch">
            <button
              className={role === "Client" ? "active" : ""}
              onClick={() => navigate("C05")}
            >
              Client
            </button>
            <button
              className={role === "Founder" ? "active" : ""}
              onClick={() => navigate("F05")}
            >
              Founder
            </button>
          </div>
          <button
            className="review-tool"
            aria-label={phone ? "Desktop preview" : "Mobile preview"}
            onClick={() => setPhone(!phone)}
          >
            {phone ? <Monitor size={17} /> : <Smartphone size={17} />}
          </button>
          <button
            className="review-tool"
            onClick={() => setOverlay({ kind: "catalog" })}
            aria-label="Screen library"
          >
            <LayoutGrid size={16} />
            <span>Screen library</span>
          </button>
        </div>
      </div>
      <Shell
        role={role}
        nav={screen.nav}
        navigate={navigate}
        onCatalog={() => setOverlay({ kind: "catalog" })}
        onNotifications={() => setOverlay({ kind: "notifications" })}
        onMenu={() => setOverlay({ kind: "navigation" })}
        unread={notices.filter((n) => !n.read).length}
        mobile={phone || Boolean(screen.mobile)}
      >
        {main}
      </Shell>
      <div className="review-pagination">
        <span>
          {id} · {screen.mobile ? "Mobile" : role} workspace
        </span>
        <span>For your review · September 2026</span>
        <div>
          <button
            aria-label="Previous screen"
            onClick={() =>
              navigate(
                screens[(index + screens.length - 1) % screens.length].id,
              )
            }
          >
            <ArrowLeft size={16} />
          </button>
          <button
            aria-label="Next screen"
            onClick={() => navigate(screens[(index + 1) % screens.length].id)}
          >
            <ArrowRight size={16} />
          </button>
        </div>
      </div>
      {toast && (
        <div className="toast" role="status">
          <CheckCircle2 size={18} />
          {toast}
        </div>
      )}
      {overlay?.kind === "navigation" && (
        <Modal title="Your workspace" onClose={() => setOverlay(null)}>
          <div className="workspace-menu">
            {(role === "Founder" ? founderNav : clientNav).map(
              ([label, target, Icon]) => (
                <button key={target} onClick={() => navigate(target)}>
                  <Icon size={20} />
                  {label}
                  <ArrowRight size={16} />
                </button>
              ),
            )}
            <button onClick={() => navigate("C19")}>
              <LayoutGrid size={20} />
              Services
              <ArrowRight size={16} />
            </button>
            <button
              onClick={() => navigate(role === "Founder" ? "F30" : "C23")}
            >
              <CircleHelp size={20} />
              Settings and help
              <ArrowRight size={16} />
            </button>
          </div>
        </Modal>
      )}
      {overlay?.kind === "catalog" && (
        <Catalog
          screens={screens}
          onClose={() => setOverlay(null)}
          navigate={navigate}
        />
      )}
      {overlay?.kind === "new" && (
        <NewRequestDialog
          defaultBug={overlay.bug}
          onClose={() => setOverlay(null)}
          onCreate={createRequest}
        />
      )}
      {overlay?.kind === "move" && selected && (
        <MoveDialog
          request={selected}
          role={role}
          initial={overlay.destination}
          onClose={() => setOverlay(null)}
          onConfirm={(state, summary) => move(selected, state, summary)}
        />
      )}
      {overlay?.kind === "detail" && selected && (
        <DetailDialog
          request={selected}
          onClose={() => setOverlay(null)}
          canMove={destinations(selected, role).length > 0}
          onMove={() => setOverlay({ kind: "move", id: selected.id })}
          onComment={(text) => {
            setRequests((prev) =>
              prev.map((r) =>
                r.id === selected.id ? { ...r, comments: r.comments + 1 } : r,
              ),
            );
            setToast(`Comment added to ${selected.id}: ${text}`);
          }}
        />
      )}
      {overlay?.kind === "notifications" && (
        <Notifications
          notices={notices}
          onClose={() => setOverlay(null)}
          onRead={() =>
            setNotices((prev) => prev.map((n) => ({ ...n, read: true })))
          }
          onEmail={(notice) => setOverlay({ kind: "email", notice })}
        />
      )}
      {overlay?.kind === "email" && (
        <EmailDialog
          notice={overlay.notice}
          onClose={() => setOverlay({ kind: "notifications" })}
          navigate={navigate}
        />
      )}
      {overlay?.kind === "action" && (
        <Modal title={overlay.label} onClose={() => setOverlay(null)}>
          <div className="action-reference">
            <CircleHelp size={28} />
            <h3>This step is a visual reference.</h3>
            <p>
              The production action uses the existing FSS service. This review
              prototype does not send messages, process payments or change
              account access.
            </p>
            <p>
              You can edit the fields and inspect the next screen in the screen
              library.
            </p>
            <Button
              icon={LayoutGrid}
              onClick={() => setOverlay({ kind: "catalog" })}
            >
              Explore related screens
            </Button>
          </div>
        </Modal>
      )}
    </>
  );
}
