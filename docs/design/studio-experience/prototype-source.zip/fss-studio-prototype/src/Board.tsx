import { useState } from "react";
import { useCardDrag } from "./useCardDrag";
import {
  ArrowRight,
  Bug,
  CalendarDays,
  CheckCheck,
  CheckCircle2,
  ChevronDown,
  Columns3,
  FileText,
  GripVertical,
  LayoutGrid,
  List,
  MessageCircle,
  MoreHorizontal,
  Paperclip,
  Plus,
  Search,
  SlidersHorizontal,
  Sparkles,
} from "lucide-react";
import { Avatar, Badge, Button, IconButton, People, Progress } from "./ui";
import { destinations, lanes } from "./request-data";
import type { RequestItem, RequestState, Role } from "./types";

interface BoardProps {
  role: Role;
  requests: RequestItem[];
  navigate: (id: string) => void;
  onNew: () => void;
  onOpen: (request: RequestItem) => void;
  onMove: (request: RequestItem, destination?: RequestState) => void;
  notify: (message: string) => void;
}
function RequestCard({
  request,
  role,
  onOpen,
  onMove,
  onDrag,
  onOver,
}: {
  request: RequestItem;
  role: Role;
  onOpen: () => void;
  onMove: (destination?: RequestState) => void;
  onOver: (lane: string | null) => void;
  onDrag: (id: string | null) => void;
}) {
  const handleDrag = useCardDrag(request, role, onMove, onDrag, onOver);
  const canMove = destinations(request, role).length > 0;
  const inReview = request.state === "Ready for review";
  return (
    <article className={`request-card ${inReview ? "review-card" : ""}`}>
      <div className="card-meta">
        <Badge
          tone={
            request.type === "Bug"
              ? "red"
              : request.type === "Design"
                ? "purple"
                : "teal"
          }
        >
          {request.type === "Bug" ? (
            <Bug size={12} />
          ) : request.type === "Design" ? (
            <Sparkles size={12} />
          ) : (
            <FileText size={12} />
          )}{" "}
          {request.type}
        </Badge>
        <span className="request-ref">{request.id}</span>
        <IconButton
          icon={MoreHorizontal}
          label={`Open options for ${request.id}`}
          onClick={canMove ? () => onMove() : onOpen}
        />
      </div>
      <button className="card-title" onClick={onOpen}>
        {request.title}
      </button>
      <p>{request.description}</p>
      <div className="card-status">
        <span
          className={`status-dot ${request.state === "Done" ? "green" : ""}`}
        />
        {request.state}
        {role === "Founder" && request.priority === "High" && (
          <span className="priority-label">High priority</span>
        )}
      </div>
      {inReview ? (
        <div className="review-callout">
          <CheckCheck size={16} />
          <span>Version 3 is ready</span>
          <button onClick={onOpen}>
            Review
            <ArrowRight size={14} />
          </button>
        </div>
      ) : (
        <Progress value={request.done} max={request.total} label="Checklist" />
      )}
      <div className="card-footer">
        <Avatar name={request.owner} />
        <span className="card-date">{request.date}</span>
        <span
          className="card-count"
          title={`${request.attachments} attachments`}
        >
          <Paperclip size={14} />
          {request.attachments}
        </span>
        <span className="card-count" title={`${request.comments} comments`}>
          <MessageCircle size={14} />
          {request.comments}
        </span>
      </div>
      {canMove && (
        <button
          className="move-handle"
          {...handleDrag}
          title="Drag to a stage, or click to choose"
        >
          <GripVertical size={14} />
          Move to
          <ChevronDown size={12} />
        </button>
      )}
    </article>
  );
}
export function Board({
  role,
  requests,
  navigate,
  onNew,
  onOpen,
  onMove,
}: BoardProps) {
  const [query, setQuery] = useState("");
  const [list, setList] = useState(false);
  const [filter, setFilter] = useState("All requests");
  const [filterOpen, setFilterOpen] = useState(false);
  const [sort, setSort] = useState("Recent activity");
  const [drag, setDrag] = useState<string | null>(null);
  const [over, setOver] = useState<string | null>(null);
  const filtered = requests
    .filter(
      (r) =>
        `${r.id} ${r.title} ${r.description}`
          .toLowerCase()
          .includes(query.toLowerCase()) &&
        (filter === "All requests" ||
          (filter === "Bugs" && r.type === "Bug") ||
          (filter === "Needs review" && r.state === "Ready for review")),
    )
    .sort((a, b) => (sort === "Title" ? a.title.localeCompare(b.title) : 0));
  const dragged = requests.find((r) => r.id === drag);
  const reviewCount = requests.filter(
    (r) => r.state === "Ready for review",
  ).length;
  return (
    <>
      <div className="page-heading">
        <div>
          <div className="eyebrow">YOUR WORK, TOGETHER</div>
          <h1>
            {role === "Founder"
              ? "Delivery workspace"
              : "Website & booking experience"}
          </h1>
          <div className="project-meta">
            <span>Northstar Studio</span>
            <span className="meta-divider" />
            <span>
              <CalendarDays size={15} />
              15 Sep – 30 Oct 2026
            </span>
            <Badge>In progress</Badge>
          </div>
        </div>
        <div className="heading-actions">
          <People />
          <Button
            secondary
            icon={LayoutGrid}
            onClick={() => navigate(role === "Founder" ? "F03" : "C04")}
          >
            Project details
          </Button>
        </div>
      </div>
      <nav className="project-tabs" aria-label="Project views">
        <button onClick={() => navigate(role === "Founder" ? "F01" : "C04")}>
          <LayoutGrid size={18} />
          Overview
        </button>
        <button onClick={() => setList(true)} aria-pressed={list}>
          <List size={18} />
          List
        </button>
        <button
          className={!list ? "selected" : ""}
          onClick={() => setList(false)}
          aria-pressed={!list}
        >
          <Columns3 size={18} />
          Board
        </button>
        <button onClick={() => navigate("C12")}>
          <FileText size={18} />
          Documents
        </button>
        <button onClick={() => navigate(role === "Founder" ? "F06" : "C08")}>
          <MessageCircle size={18} />
          Updates<small>3</small>
        </button>
      </nav>
      <div className="board-toolbar">
        <label className="search-field">
          <Search size={18} />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search requests…"
            aria-label="Search requests"
          />
        </label>
        <label className="sort-field">
          <span>Sort by</span>
          <select
            aria-label="Sort requests"
            value={sort}
            onChange={(e) => setSort(e.target.value)}
          >
            <option>Recent activity</option>
            <option>Title</option>
          </select>
        </label>
        <div className="filter-control">
          <Button
            secondary
            icon={SlidersHorizontal}
            onClick={() => setFilterOpen(!filterOpen)}
            aria-expanded={filterOpen}
          >
            {filter === "All requests" ? "Filter" : filter}
          </Button>
          {filterOpen && (
            <div className="popover" role="group" aria-label="Request filters">
              {["All requests", "Bugs", "Needs review"].map((f) => (
                <button
                  key={f}
                  onClick={() => {
                    setFilter(f);
                    setFilterOpen(false);
                  }}
                >
                  {f}
                  {filter === f && <CheckCircle2 size={16} />}
                </button>
              ))}
            </div>
          )}
        </div>
        <div className="toolbar-end">
          <span className="review-count">{reviewCount} ready for review</span>
          <Button icon={Plus} onClick={onNew}>
            New request
          </Button>
        </div>
      </div>
      {filtered.length === 0 ? (
        <div className="empty-panel">
          <Search size={32} />
          <h2>No matching requests</h2>
          <p>Try another search, or clear your filters.</p>
          <Button
            secondary
            onClick={() => {
              setQuery("");
              setFilter("All requests");
            }}
          >
            Clear filters
          </Button>
        </div>
      ) : list ? (
        <div className="request-list">
          {filtered.map((r) => (
            <button key={r.id} onClick={() => onOpen(r)}>
              <span>
                <FileText size={18} />
                {r.id}
              </span>
              <strong>{r.title}</strong>
              <Badge>{r.state}</Badge>
              <Avatar name={r.owner} />
              <ArrowRight size={16} />
            </button>
          ))}
        </div>
      ) : (
        <div className="kanban" aria-label="Request board">
          {lanes.map((lane) => {
            const valid =
              dragged && destinations(dragged, role).includes(lane.destination);
            const cards = filtered.filter((r) => lane.states.includes(r.state));
            return (
              <section
                className={`lane ${lane.tone} ${over === lane.title && valid ? "drop-target" : ""}`}
                key={lane.title}
                data-lane={lane.title}
                aria-label={`${lane.title}, ${cards.length} requests`}
              >
                <div className="lane-heading">
                  <span className="lane-dot" />
                  <h2>{lane.title}</h2>
                  <span className="lane-count">{cards.length}</span>
                  <span className="lane-symbol">
                    {lane.title === "Completed" ? (
                      <CheckCheck size={18} />
                    ) : lane.title === "In review" ? (
                      <Sparkles size={18} />
                    ) : (
                      <MoreHorizontal size={18} />
                    )}
                  </span>
                </div>
                <div className="lane-cards">
                  {cards.map((request) => (
                    <RequestCard
                      key={request.id}
                      request={request}
                      role={role}
                      onOpen={() => onOpen(request)}
                      onMove={(destination) => onMove(request, destination)}
                      onDrag={setDrag}
                      onOver={setOver}
                    />
                  ))}
                  {cards.length === 0 && (
                    <p className="lane-empty">
                      {valid ? "Drop here to continue" : "Nothing here yet."}
                    </p>
                  )}
                </div>
                {lane.title === "To do" && (
                  <button className="add-to-lane" onClick={onNew}>
                    <Plus size={16} />
                    Add a request
                  </button>
                )}
              </section>
            );
          })}
        </div>
      )}
      <div className="board-footnote">
        <span>
          <span className="online-dot" />
          All changes saved in this preview
        </span>
        <span>
          {role === "Client"
            ? "You can review and accept work. FSS manages delivery stages."
            : "Drag the grip or choose Move to. Review and completion need confirmation."}
        </span>
      </div>
    </>
  );
}
