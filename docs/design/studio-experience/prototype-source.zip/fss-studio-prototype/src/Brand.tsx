import icon from "../assets/brand/icon.png";
import wordmark from "../assets/brand/wordmark.png";

export function Brand({ compact = false }: { compact?: boolean }) {
  return (
    <span className={`brand-art ${compact ? "brand-icon" : "brand-wordmark"}`}>
      <img src={compact ? icon : wordmark} alt="Faithful Software Solutions" />
    </span>
  );
}
