import { useState } from "react";
import {
  ArrowUpRight,
  CheckCircle2,
  Columns3,
  FileText,
  LayoutGrid,
  Mail,
  Search,
  Smartphone,
  Sparkles,
} from "lucide-react";
import { Badge, Modal } from "./ui";
import type { Screen } from "./types";
export function Catalog({
  screens,
  onClose,
  navigate,
}: {
  screens: Screen[];
  onClose: () => void;
  navigate: (id: string) => void;
}) {
  const [query, setQuery] = useState("");
  const [group, setGroup] = useState("All");
  const category = (s: Screen) =>
    s.mobile
      ? "Mobile"
      : s.id.startsWith("E")
        ? "Email"
        : s.id.startsWith("S")
          ? "States"
          : s.role;
  const visible = screens.filter(
    (s) =>
      (group === "All" || category(s) === group) &&
      `${s.id} ${s.title} ${s.nav}`.toLowerCase().includes(query.toLowerCase()),
  );
  return (
    <Modal title="Explore the workspace" wide onClose={onClose}>
      <p className="modal-intro">
        {screens.length} screen references. Real layout, editable controls and
        sample interactions. Existing login screens are excluded.
      </p>
      <div className="catalog-controls">
        <label className="search-field">
          <Search size={18} />
          <input
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search screens, e.g. agreement or F23"
            aria-label="Search screen library"
          />
        </label>
        <select
          aria-label="Screen collection"
          value={group}
          onChange={(e) => setGroup(e.target.value)}
        >
          {["All", "Client", "Founder", "States", "Email", "Mobile"].map(
            (g) => (
              <option key={g}>{g}</option>
            ),
          )}
        </select>
      </div>
      <div className="catalog-count" aria-live="polite">
        {visible.length} screens
      </div>
      <div className="catalog-grid">
        {visible.map((s) => {
          const Icon = s.mobile
            ? Smartphone
            : s.id.startsWith("E")
              ? Mail
              : s.nav === "Requests" || s.nav === "Delivery"
                ? Columns3
                : s.nav === "Welcome journeys" || s.nav === "Getting started"
                  ? Sparkles
                  : s.nav === "Agreements"
                    ? FileText
                    : s.id.startsWith("S")
                      ? CheckCircle2
                      : LayoutGrid;
          return (
            <button key={s.id} onClick={() => navigate(s.id)}>
              <span className="catalog-icon">
                <Icon size={23} />
              </span>
              <div>
                <small>
                  {s.id} · {category(s)}
                </small>
                <strong>{s.title}</strong>
              </div>
              <ArrowUpRight size={16} />
            </button>
          );
        })}
      </div>
      {visible.length === 0 && <p>No matching screens. Try another search.</p>}
      <div className="catalog-legend">
        <Badge>Review draft</Badge>Use the role switcher to compare client and
        founder views.
      </div>
    </Modal>
  );
}
