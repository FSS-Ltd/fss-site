import {
  ArrowLeft,
  ArrowRight,
  CheckCheck,
  FileText,
  LockKeyhole,
} from "lucide-react";
import { useEffect, useRef } from "react";
import { Badge, Button, StepList } from "./ui";
import { RenderSection, SetupSummary } from "./Sections";
import type { ViewProps } from "./types";

const savedFields = new Map<string, string[]>();
export function GenericView({ screen, act, navigate }: ViewProps) {
  const container = useRef<HTMLDivElement>(null);
  const agreement = /^F1[0-5]$/.test(screen.id);
  const journey = /^F(19|2[0-3])$/.test(screen.id);
  const wizard = screen.sections.find((s) => s.type === "wizard");
  const labels = agreement
    ? ["Context", "Scope", "Fees", "People", "Document", "Review"]
    : ["Setup", "Content", "People", "Schedule", "Activate"];
  const current = wizard?.current ?? 1;
  const hasFields = screen.sections.some(
    (s) => s.type === "fields" || s.type === "columns",
  );
  const embedded = screen.sections.some(
    (s) =>
      s.action === screen.primary || s.actions?.includes(screen.primary ?? ""),
  );
  useEffect(() => {
    const fields = container.current?.querySelectorAll<
      HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement
    >('input:not([type="file"]):not([type="checkbox"]), textarea, select');
    const saved = savedFields.get(screen.id);
    if (saved)
      fields?.forEach((field, i) => {
        if (saved[i] !== undefined) field.value = saved[i];
      });
    return () => {
      if (fields)
        savedFields.set(
          screen.id,
          Array.from(fields).map((field) => field.value),
        );
    };
  }, [screen.id]);
  return (
    <div
      ref={container}
      className={`generic-view ${agreement || journey ? "builder-view" : ""} ${screen.id.startsWith("E") ? "email-view" : ""}`}
    >
      {(agreement || journey) && (
        <button
          className="text-button back-link"
          onClick={() => navigate(agreement ? "F09" : "F18")}
        >
          <ArrowLeft size={16} />
          {agreement ? "All agreements" : "Welcome journeys"}
        </button>
      )}
      <div className="page-heading">
        <div>
          <div className="eyebrow">
            {agreement
              ? "AGREEMENT BUILDER"
              : journey
                ? "A CONSIDERED WELCOME"
                : screen.nav.toUpperCase()}
          </div>
          <h1>{screen.title}</h1>
          <p className="page-subtitle">{screen.subtitle}</p>
        </div>
        {agreement || journey ? (
          <Badge tone="purple">
            <LockKeyhole size={12} />
            Private draft
          </Badge>
        ) : (
          screen.primary &&
          !hasFields &&
          !embedded && (
            <Button
              icon={ArrowRight}
              disabled={screen.primaryDisabled}
              onClick={() => act(screen.primary ?? "")}
            >
              {screen.primary}
            </Button>
          )
        )}
      </div>
      {(agreement || journey) && <StepList labels={labels} current={current} />}
      <div
        className={agreement || journey ? "builder-grid" : "generic-content"}
      >
        <div className="section-stack">
          {screen.sections
            .filter((s) => s.type !== "wizard")
            .map((section, i) => (
              <RenderSection
                key={`${screen.id}-${i}`}
                section={section}
                act={act}
              />
            ))}
          {screen.primary &&
            (hasFields || agreement || journey) &&
            !embedded && (
              <div className="builder-footer">
                <span>
                  <CheckCheck size={16} />
                  Sample draft · local preview
                </span>
                <Button
                  icon={ArrowRight}
                  disabled={screen.primaryDisabled}
                  onClick={() => act(screen.primary ?? "")}
                >
                  {screen.primary}
                </Button>
              </div>
            )}
        </div>
        {(agreement || journey) && (
          <aside className="builder-aside">
            <SetupSummary current={current} total={labels.length} />
            <div className="small-advice">
              <FileText size={18} />
              <p>
                {agreement
                  ? "The document fingerprint is generated automatically. You only review the named document and its version."
                  : "Starting the journey schedules the approved steps. Each delivery has its own status and recovery action."}
              </p>
            </div>
          </aside>
        )}
      </div>
    </div>
  );
}
