import {
  ArrowRight,
  ArrowUpRight,
  CalendarDays,
  Check,
  CheckCircle2,
  Clock3,
  FileText,
  Folder,
  MessageCircle,
  Plus,
  Sparkles,
  TrendingUp,
} from "lucide-react";
import { Avatar, Badge, Button, Panel, Progress, SectionHeading } from "./ui";
import { ProductPreview } from "./Review";
import type { Role } from "./types";

export function Home({
  role,
  navigate,
  onNew,
}: {
  role: Role;
  navigate: (id: string) => void;
  onNew: () => void;
}) {
  const founder = role === "Founder";
  return (
    <div className="home-view">
      <div className="page-heading">
        <div>
          <div className="eyebrow">TUESDAY, 15 SEPTEMBER</div>
          <h1>{founder ? "Your studio, in focus." : "Good morning, Alex."}</h1>
          <p className="page-subtitle">
            {founder
              ? "A clear view of your clients, delivery and next decisions."
              : "Good things are taking shape. Here’s where we are."}
          </p>
        </div>
        <Button icon={Plus} onClick={onNew}>
          New request
        </Button>
      </div>
      <div className="home-metrics">
        {(founder
          ? [
              ["3", "Active projects", "folder"],
              ["2", "Client reviews", "review"],
              ["1", "Needs attention", "clock"],
            ]
          : [
              ["2", "Ready for your review", "review"],
              ["3", "In progress", "folder"],
              ["24 Sep", "Next milestone", "clock"],
            ]
        ).map(([value, label, icon]) => (
          <button key={label} onClick={() => navigate(founder ? "F05" : "C05")}>
            <span className={`metric-icon ${icon}`}>
              {icon === "folder" ? (
                <Folder />
              ) : icon === "review" ? (
                <CheckCircle2 />
              ) : (
                <CalendarDays />
              )}
            </span>
            <span>
              <strong>{value}</strong>
              <small>{label}</small>
            </span>
            <ArrowUpRight size={17} />
          </button>
        ))}
      </div>
      <div className="home-grid">
        <Panel className="feature-review">
          <div className="feature-copy">
            <Badge tone="purple">
              <Sparkles size={13} />
              {founder ? "CLIENT REVIEW" : "READY WHEN YOU ARE"}
            </Badge>
            <h2>
              A smoother
              <br />
              booking experience.
            </h2>
            <p>
              The new prototype is ready. Take a look at the details and let us
              know what you think.
            </p>
            <Button
              icon={ArrowRight}
              onClick={() => navigate(founder ? "F07" : "C09")}
            >
              {founder ? "View review package" : "Review the update"}
            </Button>
            <div className="feature-person">
              <Avatar name="Jean Fidele" />
              <span>
                From Jean-Fidele<small>Your delivery lead</small>
              </span>
            </div>
          </div>
          <div className="feature-art">
            <ProductPreview />
          </div>
        </Panel>
        <Panel className="next-panel">
          <SectionHeading title="Your next steps" />
          <div className="task-row">
            <span className="task-icon lilac">
              <CheckCircle2 size={20} />
            </span>
            <button onClick={() => navigate("C09")}>
              <strong>Review booking flow</strong>
              <small>Version 3 · 2 minutes</small>
            </button>
            <ArrowRight size={17} />
          </div>
          <div className="task-row">
            <span className="task-icon peach">
              <FileText size={20} />
            </span>
            <button onClick={() => navigate(founder ? "F15" : "C15")}>
              <strong>
                {founder ? "Approve the agreement" : "Review your agreement"}
              </strong>
              <small>Website & booking experience</small>
            </button>
            <ArrowRight size={17} />
          </div>
          <div className="task-row">
            <span className="task-icon mint">
              <Folder size={20} />
            </span>
            <button onClick={() => navigate("C27")}>
              <strong>Share your brand assets</strong>
              <small>Needed before development</small>
            </button>
            <ArrowRight size={17} />
          </div>
          <div className="subtle-note">
            <Clock3 size={16} />
            {founder
              ? "One decision can unlock the next step."
              : "One place for everything we need from you."}
          </div>
        </Panel>
      </div>
      <div className="home-bottom">
        <Panel>
          <SectionHeading
            title={founder ? "Delivery this week" : "Your project"}
            action="View project"
            onAction={() => navigate(founder ? "F03" : "C04")}
          />
          <div className="project-summary">
            <span className="project-mark">
              N<span>✳</span>
            </span>
            <div>
              <h3>Website & booking experience</h3>
              <p>A confident online experience for Northstar.</p>
            </div>
            <Badge>In progress</Badge>
          </div>
          <div className="milestone-strip">
            {["Discovery", "Design", "Build", "Launch"].map((x, i) => (
              <span className={i < 2 ? "complete" : ""} key={x}>
                <span>{i === 0 ? <Check size={14} /> : i + 1}</span>
                {x}
              </span>
            ))}
          </div>
          <Progress value={2} max={4} label="Agreed milestones" />
        </Panel>
        <Panel>
          <SectionHeading
            title="Latest from your studio"
            action="All updates"
            onAction={() => navigate("C21")}
          />
          <div className="activity-item">
            <Avatar name="Jean Fidele" />
            <div>
              <strong>Your booking flow is ready</strong>
              <p>
                “We’ve refined the mobile experience and made the appointment
                details clearer.”
              </p>
              <small>Today · 10:24</small>
            </div>
          </div>
          <div className="activity-item">
            <span className="task-icon mint">
              <TrendingUp size={19} />
            </span>
            <div>
              <strong>One milestone closer</strong>
              <p>Discovery is complete. The direction is agreed.</p>
              <small>Yesterday · 15:30</small>
            </div>
          </div>
          <button className="text-button" onClick={() => navigate("C08")}>
            <MessageCircle size={16} />
            Send a message
          </button>
        </Panel>
      </div>
    </div>
  );
}

export function Welcome({ navigate }: { navigate: (id: string) => void }) {
  const tasks = [
    [
      "Tell us about your team",
      "Your people and contact preferences",
      "C26",
      true,
    ],
    ["Review your agreement", "Scope, fees and responsibilities", "C15", true],
    ["Confirm billing details", "The right contact for invoices", "C17", true],
    [
      "Share your brand assets",
      "Approved logos, imagery and guidelines",
      "C27",
      false,
    ],
    [
      "Choose a kickoff time",
      "A 30-minute conversation to align",
      "C28",
      false,
    ],
    [
      "Ready for the next chapter",
      "Everything in place for delivery",
      "C29",
      false,
    ],
  ] as const;
  return (
    <>
      <div className="page-heading">
        <div>
          <div className="eyebrow">A THOUGHTFUL START</div>
          <h1>Let’s make this yours.</h1>
          <p className="page-subtitle">
            A few simple steps, and we’re ready to build something good.
          </p>
        </div>
        <Badge>3 of 6 complete</Badge>
      </div>
      <div className="welcome-layout">
        <Panel className="welcome-tasks">
          <div className="welcome-progress">
            <div>
              <h2>Your getting-started checklist</h2>
              <p>Progress is saved as you go.</p>
            </div>
            <span className="progress-ring">
              50<span>%</span>
            </span>
          </div>
          <div className="checklist">
            {tasks.map(([title, body, id, done], i) => (
              <button
                key={id}
                className={
                  done ? "task-complete" : i === 3 ? "task-active" : ""
                }
                onClick={() => navigate(id)}
              >
                <span className="task-number">
                  {done ? <Check size={18} /> : i + 1}
                </span>
                <span>
                  <strong>{title}</strong>
                  <small>{body}</small>
                </span>
                {i === 3 ? (
                  <Badge>Up next</Badge>
                ) : done ? (
                  <span className="done-label">Complete</span>
                ) : (
                  <ArrowRight size={18} />
                )}
              </button>
            ))}
          </div>
        </Panel>
        <div className="welcome-aside">
          <div className="welcome-note">
            <span className="welcome-emblem">
              <Sparkles size={30} />
            </span>
            <h2>
              Great work begins
              <br />
              with a clear start.
            </h2>
            <p>
              You’ll always know what’s happening, what we need from you and
              what comes next.
            </p>
            <div className="feature-person">
              <Avatar name="Jean Fidele" size="large" />
              <span>
                Jean-Fidele<small>Your studio partner</small>
              </span>
            </div>
            <button className="text-button" onClick={() => navigate("C22")}>
              Need a hand?
              <ArrowUpRight size={16} />
            </button>
          </div>
          <Panel>
            <h3>Your project guide</h3>
            <p>How we work together, in one useful place.</p>
            <Button secondary icon={FileText} onClick={() => navigate("C13")}>
              Open welcome guide
            </Button>
          </Panel>
        </div>
      </div>
    </>
  );
}
