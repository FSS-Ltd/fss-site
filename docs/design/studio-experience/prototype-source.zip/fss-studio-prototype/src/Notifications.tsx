import { Brand } from "./Brand";
import { Bell, Check, CheckCheck, Mail, Sparkles } from "lucide-react";
import { Badge, Button, Modal } from "./ui";
import type { Notice } from "./types";
export function Notifications({
  notices,
  onClose,
  onRead,
  onEmail,
}: {
  notices: Notice[];
  onClose: () => void;
  onRead: () => void;
  onEmail: (notice: Notice) => void;
}) {
  return (
    <Modal title="Your updates" onClose={onClose}>
      <div className="inbox-toolbar">
        <Badge>{notices.filter((n) => !n.read).length} unread</Badge>
        <button className="text-button" onClick={onRead}>
          <CheckCheck size={16} />
          Mark all as read
        </button>
      </div>
      <div className="inbox-list">
        {notices.map((n) => (
          <article key={n.id} className={n.read ? "read" : ""}>
            <span className="inbox-icon">
              {n.title.includes("complete") ? (
                <Check size={20} />
              ) : (
                <Bell size={20} />
              )}
            </span>
            <div>
              <strong>{n.title}</strong>
              <p>{n.body}</p>
              <button className="text-button" onClick={() => onEmail(n)}>
                <Mail size={15} />
                Preview email
              </button>
            </div>
            {!n.read && <span className="unread-dot" />}
          </article>
        ))}
      </div>
      <p className="form-note">
        In this design preview, updates stay in memory and emails are previews
        only.
      </p>
    </Modal>
  );
}
export function EmailDialog({
  notice,
  onClose,
  navigate,
}: {
  notice: Notice;
  onClose: () => void;
  navigate: (id: string) => void;
}) {
  return (
    <Modal title="Email preview" onClose={onClose}>
      <div className="email-envelope">
        <div>
          <span>To</span>
          <strong>Alex Morgan · alex@northstar.example</strong>
        </div>
        <div>
          <span>Subject</span>
          <strong>{notice.title}</strong>
        </div>
        <Badge tone="purple">Preview only · not sent</Badge>
      </div>
      <article className="email-paper">
        <div className="email-brand">
          <Brand />
          <span>YOUR SOFTWARE STUDIO</span>
        </div>
        <Sparkles size={28} />
        <h2>{notice.title}</h2>
        <p>Hello Alex,</p>
        <p>{notice.body}</p>
        <Button
          onClick={() =>
            navigate(notice.title.includes("complete") ? "C11" : "C09")
          }
        >
          {notice.title.includes("complete")
            ? "View completed work"
            : "Review your update"}
        </Button>
        <p>
          Jean-Fidele
          <br />
          <small>Faithful Software Solutions</small>
        </p>
      </article>
    </Modal>
  );
}
