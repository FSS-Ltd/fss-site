import { useState, type FormEvent } from "react";
import {
  ArrowRight,
  CheckCircle2,
  CircleHelp,
  Mail,
  MessageCircle,
  Paperclip,
  Send,
} from "lucide-react";
import { Avatar, Badge, Button, Modal } from "./ui";
import { ReviewContent } from "./Review";
import { destinations } from "./request-data";
import type { RequestItem, RequestState, Role } from "./types";

export function NewRequestDialog({
  onClose,
  onCreate,
  defaultBug = false,
}: {
  onClose: () => void;
  onCreate: (data: {
    title: string;
    description: string;
    type: "Request" | "Bug";
  }) => void;
  defaultBug?: boolean;
}) {
  const [type, setType] = useState<"Request" | "Bug">(
    defaultBug ? "Bug" : "Request",
  );
  const [files, setFiles] = useState<string[]>([]);
  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    onCreate({
      title: String(form.get("title")).trim(),
      description: String(form.get("description")).trim(),
      type,
    });
  }
  return (
    <Modal title="A good idea starts here." onClose={onClose}>
      <p className="modal-intro">
        Tell us what you need. We’ll take it from here.
      </p>
      <form onSubmit={submit} className="form-stack">
        <div className="segmented">
          <button
            type="button"
            className={type === "Request" ? "selected" : ""}
            onClick={() => setType("Request")}
          >
            New request
          </button>
          <button
            type="button"
            className={type === "Bug" ? "selected" : ""}
            onClick={() => setType("Bug")}
          >
            Report a bug
          </button>
        </div>
        <label>
          Project
          <select name="project">
            <option>Website & booking experience</option>
          </select>
        </label>
        <label>
          {type === "Bug"
            ? "What went wrong?"
            : "What would you like us to do?"}
          <input
            name="title"
            required
            minLength={3}
            maxLength={160}
            placeholder={
              type === "Bug"
                ? "The booking confirmation shows the wrong time"
                : "Add a customer preferences page"
            }
            autoFocus
          />
        </label>
        <label>
          {type === "Bug" ? "Steps to reproduce" : "A little more detail"}
          <textarea
            name="description"
            required
            minLength={5}
            rows={3}
            placeholder={
              type === "Bug"
                ? "1. Open the booking page…"
                : "What would a good outcome look like?"
            }
          />
        </label>
        {type === "Bug" && (
          <div className="field-grid">
            <label>
              Expected result
              <textarea required rows={2} />
            </label>
            <label>
              Actual result
              <textarea required rows={2} />
            </label>
          </div>
        )}
        <label className="upload-control">
          <Paperclip size={18} />
          <span>
            Add screenshots or files
            <small>
              {files.length
                ? files.join(", ")
                : "Selected filenames are shown locally. Nothing is uploaded."}
            </small>
          </span>
          <input
            type="file"
            multiple
            onChange={(e) =>
              setFiles(Array.from(e.target.files ?? []).map((f) => f.name))
            }
          />
        </label>
        <div className="form-note">
          <CircleHelp size={17} />
          FSS will confirm scope and next steps before work begins.
        </div>
        <div className="modal-footer">
          <Button type="button" secondary onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" icon={Send}>
            Submit {type === "Bug" ? "bug report" : "request"}
          </Button>
        </div>
      </form>
    </Modal>
  );
}
export function MoveDialog({
  request,
  role,
  initial,
  onClose,
  onConfirm,
}: {
  request: RequestItem;
  role: Role;
  initial?: RequestState;
  onClose: () => void;
  onConfirm: (state: RequestState, summary: string) => void;
}) {
  const options = destinations(request, role);
  const [state, setState] = useState<RequestState>(
    initial ?? options[0] ?? request.state,
  );
  const [summary, setSummary] = useState("");
  if (role === "Client" && request.state === "Ready for review")
    return (
      <Modal title={`Review ${request.id}`} wide onClose={onClose}>
        <ReviewContent request={request} onDecision={onConfirm} />
      </Modal>
    );
  return (
    <Modal title="Move work forward" onClose={onClose}>
      <div className="move-summary">
        <Badge>{request.id}</Badge>
        <h3>{request.title}</h3>
        <p>Currently {request.state.toLowerCase()}.</p>
      </div>
      <form
        className="form-stack"
        onSubmit={(e) => {
          e.preventDefault();
          onConfirm(state, summary);
        }}
      >
        <label>
          Move to
          <select
            value={state}
            onChange={(e) => {
              const selected = options.find((o) => o === e.target.value);
              if (selected) setState(selected);
            }}
          >
            {options.map((o) => (
              <option key={o}>{o}</option>
            ))}
          </select>
        </label>
        {state === "Ready for review" && (
          <>
            <label>
              Deliverable
              <select>
                <option>{request.title} · Version 3 · retained</option>
              </select>
            </label>
            <label>
              Reviewer
              <select>
                <option>Alex Morgan · Client owner</option>
              </select>
            </label>
          </>
        )}
        <label>
          {state === "Ready for review"
            ? "What should the client review?"
            : "Next step"}
          <textarea
            value={summary}
            onChange={(e) => setSummary(e.target.value)}
            required
            minLength={5}
            rows={3}
            placeholder="Add a clear, useful update…"
          />
        </label>
        {state === "Ready for review" && (
          <div className="form-note">
            <Mail size={18} />
            Creates an in-app update and an email preview for Alex. No email is
            sent from this prototype.
          </div>
        )}
        <div className="modal-footer">
          <Button secondary type="button" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" icon={ArrowRight}>
            {state === "Ready for review" ? "Publish review" : "Confirm move"}
          </Button>
        </div>
      </form>
    </Modal>
  );
}
export function DetailDialog({
  request,
  onClose,
  onMove,
  onComment,
  canMove,
}: {
  request: RequestItem;
  onClose: () => void;
  onMove: () => void;
  onComment: (text: string) => void;
  canMove: boolean;
}) {
  const [comment, setComment] = useState("");
  return (
    <Modal title={request.title} onClose={onClose}>
      <div className="detail-badges">
        <Badge>{request.id}</Badge>
        <Badge tone="purple">{request.state}</Badge>
      </div>
      <p className="detail-description">{request.description}</p>
      <div className="detail-facts">
        <div>
          <small>Owner</small>
          <span>
            <Avatar name={request.owner} />
            {request.owner}
          </span>
        </div>
        <div>
          <small>Next date</small>
          <strong>{request.date}</strong>
        </div>
      </div>
      <div className="activity-item">
        <CheckCircle2 size={20} />
        <div>
          <strong>Request is {request.state.toLowerCase()}</strong>
          <p>Your updates and decisions stay connected to this work.</p>
        </div>
      </div>
      <form
        className="form-stack"
        onSubmit={(e) => {
          e.preventDefault();
          onComment(comment);
          setComment("");
        }}
      >
        <label>
          Add a comment
          <textarea
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            required
            minLength={2}
            placeholder="Share a thought or ask a question…"
            rows={3}
          />
        </label>
        <Button secondary icon={MessageCircle} type="submit">
          Post comment
        </Button>
      </form>
      {canMove && (
        <div className="modal-footer">
          <Button icon={ArrowRight} onClick={onMove}>
            Move to next stage
          </Button>
        </div>
      )}
    </Modal>
  );
}
