import { useState } from "react";
import {
  ArrowRight,
  Check,
  FileText,
  Send,
  ShieldCheck,
  Sparkles,
} from "lucide-react";
import { Avatar, Badge, Button } from "./ui";
import type { RequestItem, RequestState } from "./types";

export function ProductPreview() {
  return (
    <div className="product-preview" aria-label="Example booking prototype">
      <div className="mini-browser">
        <span />
        <span />
        <span />
        <small>northstar.studio / book</small>
      </div>
      <div className="mini-site">
        <div className="mini-brand">
          northstar<span>STUDIO</span>
        </div>
        <span className="mini-caption">A MOMENT FOR YOU</span>
        <h3>
          Good things
          <br />
          start here.
        </h3>
        <p>
          Make space for something
          <br />
          that feels like you.
        </p>
        <div className="mini-booking">
          <div>
            <span>Discovery session</span>
            <strong>Wednesday, 23 September</strong>
          </div>
          <span className="mini-arrow">
            <ArrowRight size={18} />
          </span>
        </div>
        <div className="mini-slots">
          <span>10:00</span>
          <span className="chosen">11:30</span>
          <span>14:00</span>
        </div>
        <div className="mini-footer">
          <ShieldCheck size={13} />
          Your time. Thoughtfully planned.
        </div>
      </div>
    </div>
  );
}
export function ReviewContent({
  request,
  onDecision,
}: {
  request: RequestItem;
  onDecision: (state: RequestState, feedback: string) => void;
}) {
  const [accepted, setAccepted] = useState(false);
  const [changes, setChanges] = useState(false);
  const [feedback, setFeedback] = useState("");
  return (
    <div className="review-layout">
      <div>
        {request.id === "NS-011" || request.id === "NS-012" ? (
          <ProductPreview />
        ) : (
          <div className="document-sheet">
            <div className="eyebrow">NORTHSTAR STUDIO · VERSION 3</div>
            <h2>{request.title}</h2>
            <p>{request.description}</p>
            <hr />
            <h3>Ready for your review</h3>
            <p>
              Check the content, details and next steps against the agreed
              outcome.
            </p>
            <div className="form-note">
              <ShieldCheck size={18} />
              Retained version · Client review copy
            </div>
          </div>
        )}
        <div className="preview-caption">
          <FileText size={16} />
          {request.title} · Version 3<Badge>Latest version</Badge>
        </div>
      </div>
      <div className="review-detail">
        <Badge tone="purple">
          <Sparkles size={13} />
          Ready for you
        </Badge>
        <h2>{request.title}</h2>
        <p>
          {request.description} Please check version 3 against the agreed
          outcome.
        </p>
        <h3>What to check</h3>
        <ul className="check-list">
          <li>
            <Check size={16} />
            Content and agreed scope
          </li>
          <li>
            <Check size={16} />
            Details, dates and next steps
          </li>
          <li>
            <Check size={16} />
            Clarity for your customers
          </li>
        </ul>
        <div className="reviewer">
          <Avatar name="Alex Morgan" />
          <div>
            <strong>Alex Morgan</strong>
            <small>Designated reviewer · Version 3</small>
          </div>
        </div>
        {changes ? (
          <form
            onSubmit={(e) => {
              e.preventDefault();
              onDecision("Changes requested", feedback);
            }}
            className="form-stack"
          >
            <label>
              What needs changing?
              <textarea
                required
                minLength={5}
                value={feedback}
                onChange={(e) => setFeedback(e.target.value)}
                placeholder="Tell us what needs adjusting…"
                rows={3}
              />
            </label>
            <Button type="submit" icon={Send}>
              Send feedback
            </Button>
            <Button secondary type="button" onClick={() => setChanges(false)}>
              Back to review
            </Button>
          </form>
        ) : (
          <>
            <label className="check-field">
              <input
                type="checkbox"
                checked={accepted}
                onChange={(e) => setAccepted(e.target.checked)}
              />
              <span>
                I’ve reviewed version 3 and it meets the agreed outcome.
              </span>
            </label>
            <div className="decision-actions">
              <Button
                icon={Check}
                disabled={!accepted}
                onClick={() => onDecision("Done", "Accepted version 3")}
              >
                Accept version 3
              </Button>
              <Button secondary onClick={() => setChanges(true)}>
                Request changes
              </Button>
            </div>
            <small className="quiet">
              Your decision is recorded against this exact version.
            </small>
          </>
        )}
      </div>
    </div>
  );
}
