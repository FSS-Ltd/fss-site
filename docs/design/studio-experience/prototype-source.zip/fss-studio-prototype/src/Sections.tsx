import { Brand } from "./Brand";
import { useState } from "react";
import {
  ArrowRight,
  Check,
  CheckCircle2,
  ChevronDown,
  FileCheck2,
  FileText,
  Info,
  LockKeyhole,
  Paperclip,
  ShieldCheck,
  Sparkles,
} from "lucide-react";
import { Badge, Button, Panel, Progress, SectionHeading } from "./ui";
import type { Section } from "./types";

function Field({ item }: { item: string[] }) {
  const [label, raw = "", hint] = item;
  const cleanValue = raw.replace(/[⌄▾]/g, "").trim();
  const value =
    label === "Engagement" ? cleanValue.split(" · ")[0] : cleanValue;
  const options = raw.includes("⌄") || raw.includes("▾");
  const multiline =
    /description|instructions|scope|outcome|message|feedback|notes|body|terms|exclusions|assumptions|steps|result/i.test(
      label,
    );
  const file = /^(files?|attachment|signed file)$/i.test(label);
  const [filename, setFilename] = useState("");
  if (file)
    return (
      <label className="field full">
        {label}
        <span className="file-input">
          <Paperclip size={22} />
          <span>
            {filename || "Choose a file"}
            <small>Selected locally for design review</small>
          </span>
          <input
            type="file"
            onChange={(e) => setFilename(e.target.files?.[0]?.name ?? "")}
          />
        </span>
        {hint && <small>{hint}</small>}
      </label>
    );
  return (
    <label className={`field ${multiline ? "full" : ""}`}>
      {label}
      {options ? (
        <span className="select-wrap">
          <select defaultValue={value}>
            <option>{value}</option>
            {/client|organisation/i.test(label) && (
              <option>Harbor Foundation</option>
            )}
            {/role/i.test(label) && (
              <>
                <option>Contributor</option>
                <option>Viewer</option>
              </>
            )}
            {/required|yes|no/i.test(value) && (
              <option>{value === "Yes" ? "No" : "Yes"}</option>
            )}
          </select>
          <ChevronDown size={16} />
        </span>
      ) : multiline ? (
        <textarea defaultValue={value} rows={value.length > 120 ? 4 : 3} />
      ) : (
        <input
          defaultValue={value}
          type={/email/i.test(label) ? "email" : "text"}
        />
      )}{" "}
      {hint && <small>{hint}</small>}
    </label>
  );
}
export function RenderSection({
  section: s,
  act,
}: {
  section: Section;
  act: (label: string) => void;
}) {
  if (s.type === "columns")
    return (
      <div className="section-columns">
        {s.left && <RenderSection section={s.left} act={act} />}{" "}
        {s.right && <RenderSection section={s.right} act={act} />}
      </div>
    );
  if (s.type === "wizard") return null;
  if (s.type === "metrics")
    return (
      <div className="generic-metrics">
        {s.items?.map((row, i) => {
          const values = Array.isArray(row) ? row : [row];
          return (
            <Panel key={i}>
              <span className="metric-icon">
                {i === 0 ? (
                  <FileText />
                ) : i === 1 ? (
                  <CheckCircle2 />
                ) : (
                  <Sparkles />
                )}
              </span>
              <strong>{values[0]}</strong>
              <small>{values[1]}</small>
            </Panel>
          );
        })}
      </div>
    );
  if (s.type === "notice")
    return (
      <aside className={`notice ${s.tone === "warningTint" ? "warning" : ""}`}>
        <Info size={20} />
        <div>
          <strong>{s.title}</strong>
          <p>{s.body}</p>
        </div>
      </aside>
    );
  if (s.type === "hero")
    return (
      <div
        className={`content-hero ${s.tone === "successTint" ? "success-hero" : ""}`}
      >
        <span className="hero-symbol">
          {s.tone === "successTint" ? (
            <CheckCircle2 size={30} />
          ) : (
            <Sparkles size={30} />
          )}
        </span>
        <div>
          <h2>{s.title}</h2>
          <p>{s.body}</p>
          {s.action && (
            <Button icon={ArrowRight} onClick={() => act(s.action ?? "")}>
              {s.action}
            </Button>
          )}
        </div>
      </div>
    );
  if (s.type === "choices") return <ChoiceGroup section={s} act={act} />;
  if (s.type === "fields")
    return (
      <Panel className="form-panel">
        <SectionHeading title={s.title ?? "Details"} />
        <div className="field-grid">
          {s.items?.map((item, i) => (
            <Field
              key={`${s.title}-${i}`}
              item={Array.isArray(item) ? item : [item]}
            />
          ))}
        </div>
      </Panel>
    );
  if (s.type === "timeline")
    return (
      <Panel>
        <SectionHeading title={s.title ?? "Your next steps"} />
        <div className="timeline">
          {s.items?.map((item, i) => {
            const [mark, title, body] = Array.isArray(item) ? item : [item];
            return (
              <div
                className={`timeline-row ${mark === "✓" ? "done" : ""}`}
                key={i}
              >
                <span className="timeline-mark">
                  {mark === "✓" ? <Check size={16} /> : mark}
                </span>
                <div>
                  <strong>{title}</strong>
                  <p>{body}</p>
                </div>
              </div>
            );
          })}
        </div>
      </Panel>
    );
  if (s.type === "document")
    return (
      <Panel className="document-panel">
        <div className="document-toolbar">
          <FileText size={18} />
          <span>{s.title}</span>
          <Badge>Retained version</Badge>
        </div>
        <article className="document-paper">
          <div className="document-brand">
            <Brand />
            <small>FAITHFUL SOFTWARE SOLUTIONS</small>
          </div>
          <div className="document-kicker">MADE CLEAR. BUILT TOGETHER.</div>
          <h2>{s.title}</h2>
          <p>{s.body}</p>
          <div className="document-rule" />
          <div className="document-signoff">
            <ShieldCheck size={17} />
            <span>
              {s.caption ?? "Exact approved version · Securely retained"}
            </span>
          </div>
        </article>
      </Panel>
    );
  if (s.type === "review") return <ReviewCheck section={s} act={act} />;
  if (s.type === "skeleton")
    return (
      <Panel>
        <span role="status">Loading your workspace…</span>
        {[1, 2, 3].map((i) => (
          <div className="skeleton" key={i} />
        ))}
      </Panel>
    );
  if (s.type === "pricing")
    return (
      <Panel>
        <SectionHeading title={s.title ?? "Agreed fees"} />
        <div className="fee-table">
          {s.items?.map((r, i) => (
            <div key={i}>
              {(Array.isArray(r) ? r : [r]).map((v, n) => (
                <span key={n}>{v}</span>
              ))}
            </div>
          ))}
        </div>
        <div className="fee-total">
          <span>Agreement total</span>
          <strong>{s.total}</strong>
        </div>
        <Button secondary onClick={() => act("Add line item")}>
          Add line item
        </Button>
      </Panel>
    );
  return (
    <Panel>
      <SectionHeading title={s.title ?? "Details"} />
      {s.items?.map((item, i) => {
        const [title, body, action] = Array.isArray(item) ? item : [item];
        return (
          <div className="content-row" key={i}>
            <span className={`row-symbol tone-${i % 4}`}>
              {/sign|agreement/i.test(title) ? (
                <FileCheck2 size={21} />
              ) : s.type === "settings" ? (
                <LockKeyhole size={21} />
              ) : (
                <FileText size={21} />
              )}
            </span>
            <div>
              <strong>{title}</strong>
              <p>{body}</p>
            </div>
            {action && (
              <Button secondary onClick={() => act(action)}>
                {action}
                <ArrowRight size={15} />
              </Button>
            )}
            {s.type === "settings" && (
              <Toggle label={title} initial={body === "On"} />
            )}
          </div>
        );
      })}
      {!s.items && s.body && <p>{s.body}</p>}
    </Panel>
  );
}
function ChoiceGroup({
  section,
  act,
}: {
  section: Section;
  act: (label: string) => void;
}) {
  const [selected, setSelected] = useState(section.selected ?? 0);
  return (
    <div className="choices">
      <span>{section.title}</span>
      <div className="segmented">
        {section.items?.map((item, i) => (
          <button
            className={i === selected ? "selected" : ""}
            key={i}
            onClick={() => {
              setSelected(i);
              const value = String(item);
              if (/bug report|new request/i.test(value)) act(value);
            }}
          >
            {item}
          </button>
        ))}
      </div>
    </div>
  );
}
function ReviewCheck({
  section,
  act,
}: {
  section: Section;
  act: (label: string) => void;
}) {
  const [checked, setChecked] = useState(false);
  return (
    <Panel>
      <SectionHeading title={section.title ?? "Your confirmation"} />
      <label className="check-field">
        <input
          type="checkbox"
          checked={checked}
          onChange={(e) => setChecked(e.target.checked)}
        />
        <span>{section.body}</span>
      </label>
      <div className="decision-actions">
        {section.actions?.map((action, i) => (
          <Button
            key={action}
            secondary={i > 0}
            disabled={i === 0 && !checked}
            onClick={() => act(action)}
          >
            {action}
          </Button>
        ))}
      </div>
    </Panel>
  );
}
function Toggle({ label, initial }: { label: string; initial: boolean }) {
  const [on, setOn] = useState(initial);
  return (
    <button
      role="switch"
      aria-checked={on}
      aria-label={label}
      className={`toggle ${on ? "on" : ""}`}
      onClick={() => setOn(!on)}
    >
      <span />
    </button>
  );
}
export function SetupSummary({
  current,
  total,
}: {
  current: number;
  total: number;
}) {
  return (
    <div className="setup-summary">
      <ShieldCheck size={28} />
      <h3>Clear before you commit.</h3>
      <p>
        Review the exact document, people and next steps before anything is
        sent.
      </p>
      <Progress value={current} max={total} label="Current step" />
      <div className="summary-fact">
        <span>Client</span>
        <strong>Northstar Studio</strong>
      </div>
      <div className="summary-fact">
        <span>Project</span>
        <strong>Website & booking</strong>
      </div>
      <div className="summary-fact">
        <span>Draft</span>
        <Badge tone="purple">Version 2</Badge>
      </div>
    </div>
  );
}
