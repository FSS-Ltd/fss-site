import { Brand } from "./Brand";
import {
  Bell,
  Building2,
  ChevronDown,
  CircleHelp,
  Columns3,
  CreditCard,
  FileCheck2,
  FileText,
  Folder,
  House,
  LayoutGrid,
  MoreHorizontal,
  Search,
  Settings2,
  Sparkles,
  Users,
  type LucideIcon,
} from "lucide-react";
import type { ReactNode } from "react";
import { Avatar, IconButton } from "./ui";
import type { Role } from "./types";
export const clientNav: [string, string, LucideIcon][] = [
  ["Home", "C01", House],
  ["Getting started", "C02", Sparkles],
  ["Projects", "C03", Folder],
  ["Requests", "C05", Columns3],
  ["Documents", "C12", FileText],
  ["Agreements", "C14", FileCheck2],
  ["Billing", "C17", CreditCard],
  ["Team", "C24", Users],
];
export const founderNav: [string, string, LucideIcon][] = [
  ["Overview", "F01", House],
  ["Clients", "F02", Building2],
  ["Delivery", "F05", Columns3],
  ["Agreements", "F09", FileCheck2],
  ["Welcome journeys", "F18", Sparkles],
  ["Projects", "F31", Folder],
  ["Billing", "F27", CreditCard],
  ["Portal access", "F28", Users],
];
export function Shell({
  children,
  role,
  nav,
  navigate,
  onCatalog,
  onNotifications,
  onMenu,
  unread,
  mobile,
}: {
  children: ReactNode;
  role: Role;
  nav: string;
  navigate: (id: string) => void;
  onCatalog: () => void;
  onNotifications: () => void;
  onMenu: () => void;
  unread: number;
  mobile: boolean;
}) {
  const items = role === "Founder" ? founderNav : clientNav;
  return (
    <div className={`app-window ${mobile ? "phone-mode" : ""}`}>
      <aside className="rail">
        <button
          className="brand"
          onClick={() => navigate(role === "Founder" ? "F01" : "C01")}
          aria-label="FSS home"
        >
          <Brand compact />
        </button>
        <nav className="rail-nav" aria-label={`${role} navigation`}>
          {items.map(([label, id, Icon]) => (
            <button
              className={nav === label ? "active" : ""}
              aria-label={label}
              title={label}
              aria-current={nav === label ? "page" : undefined}
              key={id}
              onClick={() => navigate(id)}
            >
              <Icon size={22} strokeWidth={1.65} />
              <span className="rail-label">{label}</span>
            </button>
          ))}
        </nav>
        <div className="rail-bottom">
          <IconButton
            icon={Settings2}
            label="Settings"
            onClick={() => navigate(role === "Founder" ? "F30" : "C23")}
          />
          <IconButton
            icon={CircleHelp}
            label="Help and support"
            onClick={() => navigate("C22")}
          />
        </div>
      </aside>
      <div className="workspace">
        <header className="topbar">
          <div className="mobile-brand">
            <Brand compact />
          </div>
          <button
            className="workspace-switch"
            onClick={() => navigate(role === "Founder" ? "F02" : "C25")}
          >
            <span className="workspace-symbol">
              {role === "Founder" ? <LayoutGrid size={18} /> : <span>N</span>}
            </span>
            <strong>
              {role === "Founder" ? "FSS Studio" : "Northstar Studio"}
            </strong>
            <ChevronDown size={14} />
          </button>
          <button className="global-search" onClick={onCatalog}>
            <Search size={17} />
            <span>Search your workspace…</span>
            <kbd>⌘ K</kbd>
          </button>
          <div className="topbar-right">
            <button
              className="notification-button icon-button"
              onClick={onNotifications}
              aria-label={`Notifications, ${unread} unread`}
            >
              <Bell size={20} />
              {unread > 0 && <span />}
            </button>
            <button
              className="profile-button"
              aria-label="Account and workspace menu"
              onClick={onMenu}
            >
              <Avatar
                name={role === "Founder" ? "Jean Fidele" : "Alex Morgan"}
              />
              <span>{role === "Founder" ? "Jean-Fidele" : "Alex Morgan"}</span>
              <ChevronDown size={13} />
            </button>
          </div>
        </header>
        <main className="main-content" id="main-content">
          {children}
        </main>
        <nav className="mobile-nav" aria-label="Mobile navigation">
          {items
            .filter(([label]) =>
              role === "Founder"
                ? ["Overview", "Clients", "Delivery"].includes(label)
                : ["Home", "Projects", "Requests"].includes(label),
            )
            .map(([label, id, Icon]) => (
              <button
                key={id}
                className={nav === label ? "active" : ""}
                onClick={() => navigate(id)}
              >
                <Icon size={20} />
                <span>{label === "Getting started" ? "Start" : label}</span>
              </button>
            ))}
          <button onClick={onMenu}>
            <MoreHorizontal size={20} />
            <span>More</span>
          </button>
        </nav>
      </div>
    </div>
  );
}
