import assert from "node:assert/strict";
import test from "node:test";
import { destinations, initialRequests, lanes } from "./request-data";
import type { RequestState } from "./types";

const states: RequestState[] = [
  "New",
  "Acknowledged",
  "Planned",
  "In progress",
  "Ready for review",
  "Changes requested",
  "Done",
];
const sample = initialRequests[0];

test("every workflow state belongs to exactly one visual lane", () => {
  for (const state of states) {
    assert.equal(lanes.filter((lane) => lane.states.includes(state)).length, 1);
  }
});
test("clients can only decide on a published review", () => {
  for (const state of states) {
    assert.deepEqual(
      destinations({ ...sample, state }, "Client"),
      state === "Ready for review" ? ["Changes requested", "Done"] : [],
    );
  }
});
test("founders cannot accept work on behalf of a client", () => {
  for (const state of states) {
    assert.equal(
      destinations({ ...sample, state }, "Founder").includes("Done"),
      false,
    );
  }
  assert.deepEqual(
    destinations({ ...sample, state: "Ready for review" }, "Founder"),
    [],
  );
});
test("founder workflow preserves acknowledgement, planning and revision steps", () => {
  const progression: [RequestState, RequestState][] = [
    ["New", "Acknowledged"],
    ["Acknowledged", "Planned"],
    ["Planned", "In progress"],
    ["In progress", "Ready for review"],
    ["Changes requested", "In progress"],
  ];
  for (const [state, next] of progression)
    assert.deepEqual(destinations({ ...sample, state }, "Founder"), [next]);
});
