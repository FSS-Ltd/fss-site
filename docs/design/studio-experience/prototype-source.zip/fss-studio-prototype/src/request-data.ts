import type { RequestItem, RequestState, Role } from "./types";
export const initialRequests: RequestItem[] = [
  {
    id: "NS-017",
    title: "Customer account area",
    description:
      "A simpler way for customers to manage their bookings and preferences.",
    type: "Request",
    state: "New",
    priority: "Normal",
    owner: "Alex Morgan",
    comments: 2,
    attachments: 1,
    done: 0,
    total: 4,
    date: "Scope to confirm",
  },
  {
    id: "NS-018",
    title: "Footer link on mobile",
    description: "The contact link opens the wrong page on smaller screens.",
    type: "Bug",
    state: "Planned",
    priority: "High",
    owner: "Jean Fidele",
    comments: 3,
    attachments: 2,
    done: 1,
    total: 3,
    date: "18 Sep",
  },
  {
    id: "NS-015",
    title: "Contact preferences",
    description: "Let customers choose how they hear from your team.",
    type: "Request",
    state: "Planned",
    priority: "Low",
    owner: "Morgan Lee",
    comments: 1,
    attachments: 0,
    done: 0,
    total: 3,
    date: "24 Sep",
  },
  {
    id: "NS-014",
    title: "Booking confirmation email",
    description:
      "Clear appointment details, local times and one useful next step.",
    type: "Request",
    state: "In progress",
    priority: "High",
    owner: "Jean Fidele",
    comments: 5,
    attachments: 2,
    done: 3,
    total: 5,
    date: "18 Sep",
  },
  {
    id: "NS-012",
    title: "Refine the mobile experience",
    description:
      "More breathing room. Better spacing. Easier to use with one hand.",
    type: "Design",
    state: "In progress",
    priority: "Normal",
    owner: "Morgan Lee",
    comments: 2,
    attachments: 3,
    done: 2,
    total: 4,
    date: "20 Sep",
  },
  {
    id: "NS-009",
    title: "Services page copy",
    description:
      "Your feedback is in. We are refining the service descriptions.",
    type: "Request",
    state: "Changes requested",
    priority: "Normal",
    owner: "Jean Fidele",
    comments: 6,
    attachments: 1,
    done: 3,
    total: 4,
    date: "21 Sep",
  },
  {
    id: "NS-011",
    title: "A smoother booking flow",
    description: "The new booking prototype is ready for your feedback.",
    type: "Design",
    state: "Ready for review",
    priority: "Normal",
    owner: "Alex Morgan",
    comments: 4,
    attachments: 2,
    done: 4,
    total: 4,
    date: "Review by 18 Sep",
  },
  {
    id: "NS-010",
    title: "Your project welcome guide",
    description: "Everything your team needs for a confident start.",
    type: "Request",
    state: "Ready for review",
    priority: "Low",
    owner: "Alex Morgan",
    comments: 2,
    attachments: 1,
    done: 3,
    total: 3,
    date: "Review by 19 Sep",
  },
  {
    id: "NS-006",
    title: "Brand landing page",
    description: "A clear first impression, designed around your customers.",
    type: "Design",
    state: "Done",
    priority: "Normal",
    owner: "Morgan Lee",
    comments: 6,
    attachments: 3,
    done: 5,
    total: 5,
    date: "Accepted 12 Sep",
  },
  {
    id: "NS-004",
    title: "Contact form improvements",
    description: "Fewer fields and a reassuring confirmation message.",
    type: "Request",
    state: "Done",
    priority: "Low",
    owner: "Jean Fidele",
    comments: 3,
    attachments: 1,
    done: 3,
    total: 3,
    date: "Accepted 10 Sep",
  },
];
export const lanes: {
  title: string;
  tone: string;
  states: RequestState[];
  destination: RequestState;
}[] = [
  {
    title: "To do",
    tone: "rose",
    states: ["New", "Acknowledged", "Planned"],
    destination: "Acknowledged",
  },
  {
    title: "In progress",
    tone: "peach",
    states: ["In progress", "Changes requested"],
    destination: "In progress",
  },
  {
    title: "In review",
    tone: "sky",
    states: ["Ready for review"],
    destination: "Ready for review",
  },
  {
    title: "Completed",
    tone: "lavender",
    states: ["Done"],
    destination: "Done",
  },
];
export function destinations(request: RequestItem, role: Role): RequestState[] {
  if (role === "Client")
    return request.state === "Ready for review"
      ? ["Changes requested", "Done"]
      : [];
  switch (request.state) {
    case "New":
      return ["Acknowledged"];
    case "Acknowledged":
      return ["Planned"];
    case "Planned":
      return ["In progress"];
    case "In progress":
      return ["Ready for review"];
    case "Changes requested":
      return ["In progress"];
    default:
      return [];
  }
}
