export type Role = "Client" | "Founder";
export interface Section {
  type: string;
  title?: string;
  body?: string;
  tone?: string;
  action?: string;
  items?: (string | string[])[];
  actions?: string[];
  left?: Section;
  right?: Section;
  current?: number;
  total?: number | string;
  label?: string;
  selected?: number;
  caption?: string;
}
export interface Screen {
  id: string;
  role: string;
  nav: string;
  title: string;
  subtitle: string;
  route: string;
  primary?: string | null;
  primaryDisabled?: boolean;
  mobile?: boolean;
  sections: Section[];
}
export type RequestState =
  | "New"
  | "Acknowledged"
  | "Planned"
  | "In progress"
  | "Ready for review"
  | "Changes requested"
  | "Done";
export interface RequestItem {
  id: string;
  title: string;
  description: string;
  type: "Request" | "Bug" | "Design";
  state: RequestState;
  priority: "Normal" | "High" | "Low";
  owner: string;
  comments: number;
  attachments: number;
  done: number;
  total: number;
  date: string;
}
export interface Notice {
  id: number;
  title: string;
  body: string;
  read: boolean;
}
export interface ViewProps {
  screen: Screen;
  navigate: (id: string) => void;
  act: (label: string) => void;
}
