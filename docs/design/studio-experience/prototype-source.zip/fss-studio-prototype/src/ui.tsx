import {
  useEffect,
  useRef,
  type ButtonHTMLAttributes,
  type ReactNode,
} from "react";
import {
  ArrowUpRight,
  Check,
  ChevronRight,
  X,
  type LucideIcon,
} from "lucide-react";

export function Button({
  children,
  icon: Icon,
  secondary = false,
  className = "",
  type = "button",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & {
  icon?: LucideIcon;
  secondary?: boolean;
}) {
  return (
    <button
      type={type}
      className={`button ${secondary ? "secondary" : "primary"} ${className}`}
      {...props}
    >
      {Icon && <Icon size={17} aria-hidden="true" />}
      {children}
    </button>
  );
}
export function IconButton({
  icon: Icon,
  label,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & {
  icon: LucideIcon;
  label: string;
}) {
  return (
    <button className="icon-button" aria-label={label} title={label} {...props}>
      <Icon size={20} aria-hidden="true" />
    </button>
  );
}
export function Avatar({
  name,
  size = "small",
}: {
  name: string;
  size?: "small" | "large";
}) {
  const initials = name
    .split(" ")
    .map((s) => s[0])
    .slice(0, 2)
    .join("");
  return (
    <span
      className={`avatar ${size} avatar-${name.charCodeAt(0) % 4}`}
      title={name}
      aria-label={name}
    >
      {initials}
    </span>
  );
}
export function People() {
  return (
    <div className="people">
      <Avatar name="Jean Fidele" />
      <Avatar name="Alex Morgan" />
      <Avatar name="Morgan Lee" />
      <span className="people-count">+2</span>
    </div>
  );
}
export function Badge({
  children,
  tone = "teal",
}: {
  children: ReactNode;
  tone?: string;
}) {
  return <span className={`badge ${tone}`}>{children}</span>;
}
export function Panel({
  children,
  className = "",
}: {
  children: ReactNode;
  className?: string;
}) {
  return <section className={`panel ${className}`}>{children}</section>;
}
export function SectionHeading({
  title,
  action,
  onAction,
}: {
  title: string;
  action?: string;
  onAction?: () => void;
}) {
  return (
    <div className="section-heading">
      <h2>{title}</h2>
      {action && (
        <button className="text-button" onClick={onAction}>
          {action}
          <ArrowUpRight size={16} />
        </button>
      )}
    </div>
  );
}
export function Progress({
  value,
  max,
  label,
}: {
  value: number;
  max: number;
  label: string;
}) {
  return (
    <div className="progress-wrap">
      <div className="progress-label">
        <span>{label}</span>
        <span>
          {value}/{max}
        </span>
      </div>
      <progress value={value} max={max}>
        {value} of {max}
      </progress>
    </div>
  );
}
export function Modal({
  title,
  children,
  onClose,
  wide = false,
}: {
  title: string;
  children: ReactNode;
  onClose: () => void;
  wide?: boolean;
}) {
  const ref = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    const el = ref.current;
    el?.showModal();
    el?.querySelector<HTMLElement>("[autofocus]")?.focus();
    return () => {
      el?.close();
    };
  }, []);
  return (
    <dialog
      ref={ref}
      className={`modal ${wide ? "wide" : ""}`}
      aria-label={title}
      onCancel={onClose}
      onClick={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}
    >
      <div className="modal-head">
        <h2>{title}</h2>
        <IconButton label="Close dialog" icon={X} onClick={onClose} />
      </div>
      {children}
    </dialog>
  );
}
export function StepList({
  labels,
  current,
}: {
  labels: string[];
  current: number;
}) {
  return (
    <ol className="step-list">
      {labels.map((label, i) => (
        <li
          key={label}
          className={
            i + 1 === current ? "current" : i + 1 < current ? "complete" : ""
          }
          aria-current={i + 1 === current ? "step" : undefined}
        >
          <span>{i + 1 < current ? <Check size={15} /> : i + 1}</span>
          {label}
          {i < labels.length - 1 && <ChevronRight size={14} />}
        </li>
      ))}
    </ol>
  );
}
