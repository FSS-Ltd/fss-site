import { useRef, type PointerEvent } from "react";
import { destinations, lanes } from "./request-data";
import type { RequestItem, RequestState, Role } from "./types";

/** Pointer capture lets the same handle work with mouse, pen and touch. */
export function useCardDrag(
  request: RequestItem,
  role: Role,
  onMove: (destination?: RequestState) => void,
  onDrag: (id: string | null) => void,
  onOver: (lane: string | null) => void,
) {
  const start = useRef<{ x: number; y: number; moved: boolean } | null>(null);
  const suppressClick = useRef(false);
  function target(event: PointerEvent<HTMLButtonElement>) {
    const name = document
      .elementFromPoint(event.clientX, event.clientY)
      ?.closest<HTMLElement>("[data-lane]")?.dataset.lane;
    return lanes.find(
      (lane) =>
        lane.title === name &&
        destinations(request, role).includes(lane.destination),
    );
  }
  function reset() {
    start.current = null;
    onDrag(null);
    onOver(null);
  }
  return {
    onPointerDown(event: PointerEvent<HTMLButtonElement>) {
      if (event.button !== 0) return;
      event.currentTarget.setPointerCapture(event.pointerId);
      start.current = { x: event.clientX, y: event.clientY, moved: false };
      suppressClick.current = false;
    },
    onPointerMove(event: PointerEvent<HTMLButtonElement>) {
      if (!start.current) return;
      if (
        Math.hypot(
          event.clientX - start.current.x,
          event.clientY - start.current.y,
        ) > 6
      ) {
        start.current.moved = true;
        onDrag(request.id);
        onOver(target(event)?.title ?? null);
      }
    },
    onPointerUp(event: PointerEvent<HTMLButtonElement>) {
      const moved = start.current?.moved;
      const lane = moved ? target(event) : undefined;
      suppressClick.current = Boolean(moved);
      reset();
      if (lane) onMove(lane.destination);
    },
    onPointerCancel: reset,
    onLostPointerCapture: reset,
    onClick() {
      if (!suppressClick.current) onMove();
      suppressClick.current = false;
    },
  };
}
